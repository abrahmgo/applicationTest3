import UIKit

var str = "Hello, playground"

func arryears(smallyear: Int, bigyear: Int) -> [Int]
{
    var arrYears = [Int]()
    for a in smallyear...bigyear
    {
        arrYears.append(a)
    }
    return arrYears
}

func leapyear(year: Int) -> Bool
{
    var leapYear : Bool
    leapYear = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)
    return leapYear
}

let a,b : Int
var yearsString : String = ""
var arrYear = [Int]()
var arrLeapYear = [Int]()
a = 1995
b = 2012

arrYear = arryears(smallyear: a, bigyear: b)

for year in arrYear
{
    if leapyear(year: year)
    {
        arrLeapYear.append(year)
        yearsString = yearsString + "@\(String(year))"
        
    }
}

print("año bisiesto \(yearsString)")
